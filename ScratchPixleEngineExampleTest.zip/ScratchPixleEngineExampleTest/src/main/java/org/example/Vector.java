package org.example;

public class Vector<T extends Number> {
    public T x, y, z;

    // Default constructor
    public Vector() {
        this.x = null;
        this.y = null;
        this.z = null;
    }

    // Three-value constructor: initializes x, y, z to specified values
    public Vector(T xx, T yy, T zz) {
        this.x = xx;
        this.y = yy;
        this.z = zz;
    }

    // Override toString method for easy printing
    @Override
    public String toString() {
        return "Vector(" + x + ", " + y + ", " + z + ")";
    }

    // Method to add two Vector objects
    public Vector<T> add(Vector<T> other) {
        return new Vector<>(
                (T) Double.valueOf(this.x.doubleValue() + other.x.doubleValue()),
                (T) Double.valueOf(this.y.doubleValue() + other.y.doubleValue()),
                (T) Double.valueOf(this.z.doubleValue() + other.z.doubleValue())
        );
    }

    // Method to calculate the dot product between two vectors
    public double dot(Vector<T> other) {
        return this.x.doubleValue() * other.x.doubleValue() +
                this.y.doubleValue() * other.y.doubleValue() +
                this.z.doubleValue() * other.z.doubleValue();
    }

    // Normalize method: modifies the vector and returns the same object
    public Vector<T> normalize() {
        double length = Math.sqrt(dot(this));  // Calculate the length of the vector
        if (length > 0) {
            double invLen = 1.0 / length;  // Inverse length calculation
            this.x = (T) Double.valueOf(this.x.doubleValue() * invLen);
            this.y = (T) Double.valueOf(this.y.doubleValue() * invLen);
            this.z = (T) Double.valueOf(this.z.doubleValue() * invLen);
        }
        return this;  // Return the same object for chaining
    }

    // Method to compute how close two vectors are in terms of direction
    public double closeness(Vector<T> other) {
        // Normalize both vectors
        this.normalize();
        other.normalize();

        // Calculate the dot product of the normalized vectors
        return this.dot(other);  // Result will be between -1 and 1
    }


    //Calculate the cross product to get the vector that is perpendicular to the main two vectors.


    // Method to compute the cross product
    public Vector<T> cross(Vector<T> v) {
        return new Vector<>(
                (T) Double.valueOf(this.y.doubleValue() * v.z.doubleValue() - this.z.doubleValue() * v.y.doubleValue()),  // x component
                (T) Double.valueOf(this.z.doubleValue() * v.x.doubleValue() - this.x.doubleValue() * v.z.doubleValue()),  // y component
                (T) Double.valueOf(this.x.doubleValue() * v.y.doubleValue() - this.y.doubleValue() * v.x.doubleValue())   // z component
        );
    }

}
