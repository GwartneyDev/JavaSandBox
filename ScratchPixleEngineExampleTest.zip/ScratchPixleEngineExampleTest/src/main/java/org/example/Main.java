package org.example;

public class Main {
    public static float[][] corners = {
            { 1, -1, -5},
            { 1, -1, -3},
            { 1,  1, -5},
            { 1,  1, -3},
            {-1, -1, -5},
            {-1, -1, -3},
            {-1,  1, -5},
            {-1,  1, -3}
    };

    public static void main(String[] args) {
        int image_width = 512, image_height = 512;

        for (int i = 0; i < corners.length; i++) {
            // Access each corner's x, y, z coordinates
            float[] corner = corners[i];

            // Divide the x and y coordinates by the z coordinate to project the point onto the canvas
            float x_proj = corner[0] / -corner[2];
            float y_proj = corner[1] / -corner[2];

            // Convert from NDC [-1, 1] to screen space [0, 1]
            float x_proj_remap = (1 + x_proj) / 2;
            float y_proj_remap = (1 + y_proj) / 2;

            // Convert to pixel coordinates based on the screen size
            float x_proj_pix = x_proj_remap * image_width;
            float y_proj_pix = y_proj_remap * image_height;

            // Output the result
            System.out.printf("Corner: %d x:%f y:%f%n", i, x_proj_pix, y_proj_pix);


        }

        Vector<Double> vec = new Vector<>(3.0, 4.0, 0.0);
        System.out.println("Before normalization: " + vec);
        vec.normalize();
        System.out.println("After normalization: " + vec);

        // Example usage:
        Vector<Double> vecA = new Vector<>(3.0, 4.0, 0.0);
        Vector<Double> vecB = new Vector<>(3.0, 4.0, 5.0);

        double closeness = vecA.closeness(vecB);
        System.out.println("Closeness between vecA and vecB: " + closeness);
    }
}


